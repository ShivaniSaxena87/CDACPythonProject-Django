from django.shortcuts import render, redirect
from .forms import SignupForm
from django.contrib.auth import authenticate, login as auth_login
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Customer


@login_required
def product_cards_view(request):
    return render(request, 'product_cards.html')


def home(request):
    return render(request, 'home.html')


def login(request):
    if request.method == 'POST':
        user_id = request.POST.get('user_id')
        password = request.POST.get('password')

        if user_id and password:
            customer = Customer.objects.filter(user_id=user_id).first()

            if customer is not None and customer.password == password:
                # Debug message to check if the customer object is retrieved
                print("Customer object:", customer)

                user = authenticate(request, user_id=user_id, password=password)
                if user is not None:
                    # Debug message to check if the user object is authenticated
                    print("Authenticated user:", user)

                    auth_login(request, user)
                    # Redirect to product_cards.html after successful login
                    return redirect('product_cards')
                else:
                    # Display an error message for invalid login
                    messages.error(request, 'Authentication failed')
            else:
                # Display an error message for invalid user ID or password
                messages.error(request, 'Invalid user ID or password')
        else:
            # Display an error message if user ID or password is empty
            messages.error(request, 'User ID and password are required')

    return render(request, 'login.html')


def register(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            form.save()  # save the form data to the database
            return redirect('login')  # redirect to login page after successful signup
    else:
        form = SignupForm()
    return render(request, 'register.html', {'form': form})


def product_cards(request):
    return render(request, 'product_cards.html')
