# forms.py
from django import forms
from .models import Customer


class SignupForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = ['cust_name', 'mob_no', 'user_id', 'password']
        widgets = {
            'password': forms.PasswordInput(),  # render password field as password input
        }
