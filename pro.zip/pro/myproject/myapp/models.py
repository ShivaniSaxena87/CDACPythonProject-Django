from django.db import models
from django.contrib.auth.models import User


class Customer(models.Model):
    cust_id = models.AutoField(primary_key=True)  # auto increment field for customer ID
    cust_name = models.CharField(max_length=100)
    mob_no = models.CharField(max_length=15)
    user_id = models.CharField(max_length=50)  # for login
    password = models.CharField(max_length=50)  # for login


class Product(models.Model):
    prod_id = models.AutoField(primary_key=True)  # auto increment field for product ID
    prod_name = models.CharField(max_length=100)
    prod_price = models.DecimalField(max_digits=10, decimal_places=2)


class Order(models.Model):
    cust = models.ForeignKey(Customer, on_delete=models.CASCADE)
    prod = models.ForeignKey(Product, on_delete=models.CASCADE)
    pur_date = models.DateField(auto_now_add=True)  # purchase date, auto set to current date
    bill_amt = models.DecimalField(max_digits=10, decimal_places=2)
